<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Enter OTP</h2>
        <form action="<?php echo e(route('verify.otp.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label for="otp">OTP Code:</label>
                <input type="text" name="otp" required>
            </div>
            <button type="submit">Verify OTP</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\auth\verify-otp.blade.php ENDPATH**/ ?>