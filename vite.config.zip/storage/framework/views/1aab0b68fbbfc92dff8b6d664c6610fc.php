<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Appointments</h2>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>User</th>
                <th>Date</th>
                <th>Time</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($appointment->user->name); ?></td>
                <td><?php echo e($appointment->date); ?></td>
                <td><?php echo e($appointment->time); ?></td>
                <td><?php echo e($appointment->notes); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($appointments->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\admin\appointments\index.blade.php ENDPATH**/ ?>