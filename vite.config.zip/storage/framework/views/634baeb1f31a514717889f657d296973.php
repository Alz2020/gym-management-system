<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Welcome, <?php echo e(auth()->user()->name); ?>! </h1>
    <p>This is your dashboard.</p>

    <div class="row">
        <!-- Book Appointments -->
        <div class="col-md-4">
            <a href="<?php echo e(route('appointments.index')); ?>" class="btn btn-primary btn-block">
                📅 Book Appointments
            </a>
        </div>

        <!-- Manage Payments -->
        <div class="col-md-4">
            <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-success btn-block">
                💳 Manage Payments
            </a>
        </div>

        <!-- Track Progress -->
        <div class="col-md-4">
            <a href="<?php echo e(route('progress.index')); ?>" class="btn btn-info btn-block">
                📈 Track Progress
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\user\dashboard.blade.php ENDPATH**/ ?>