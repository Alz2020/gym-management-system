<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Contact Us</h2>
    <p>Fill out the form below to get in touch with us.</p>

    <form method="POST" action="<?php echo e(route('contact.submit')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Your Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Enter your name">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email address</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Enter your email">
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">Message</label>
            <textarea name="message" class="form-control" id="message" rows="4" placeholder="Type your message"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Message</button>
    </form>

    <hr>

    <h3 class="mt-4">Your Previous Messages</h3>
    <?php if($contacts->isEmpty()): ?>
        <p>You haven't submitted any messages yet.</p>
    <?php else: ?>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($contact->name); ?> (<?php echo e($contact->email); ?>)</h5>
                    <p class="card-text"><?php echo e($contact->message); ?></p>
                    <p class="text-muted"><?php echo e($contact->created_at->format('d M Y, H:i')); ?></>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\contact\index.blade.php ENDPATH**/ ?>