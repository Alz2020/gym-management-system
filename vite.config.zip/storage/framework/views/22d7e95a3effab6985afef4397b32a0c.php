<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">🧑‍🏫 Consulting Services</h1>
    <p class="lead">Get personalized advice and guidance from our expert trainers.</p>

    <div class="card shadow-sm p-4">
        <h4>Why Choose Our Consulting?</h4>
        <ul>
            <li>🏋️ Tailored fitness and nutrition plans</li>
            <li>📈 Monthly progress reviews</li>
            <li>📅 Flexible appointment scheduling</li>
        </ul>
        <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-primary mt-3">
            Book a Consulting Appointment
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\consulting\index.blade.php ENDPATH**/ ?>