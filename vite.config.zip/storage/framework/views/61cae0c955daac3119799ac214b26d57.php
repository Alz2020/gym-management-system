<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Settings</h2>
    <p>This section is under development. Here you will be able to manage system preferences, admin profiles, etc.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\admin\settings.blade.php ENDPATH**/ ?>