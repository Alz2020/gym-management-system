<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4">🔍 Payment Details</h2>

    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Payment ID: <?php echo e($payment->payment_reference); ?></h5>
            <p class="card-text"><strong>Amount:</strong> £<?php echo e(number_format($payment->amount, 2)); ?></p>
            <p class="card-text"><strong>Status:</strong>
                <span class="badge bg-<?php echo e($payment->status == 'Completed' ? 'success' : 'warning'); ?>">
                    <?php echo e(ucfirst($payment->status)); ?>

                </span>
            </p>
            <p class="card-text"><strong>Date:</strong> <?php echo e($payment->created_at->format('Y-m-d H:i')); ?></p>
            <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-secondary mt-3">⬅️ Back to Payments</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\payments\show.blade.php ENDPATH**/ ?>