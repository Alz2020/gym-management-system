<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Payments</h2>
    <table class="table table-hover mt-3">
        <thead>
            <tr>
                <th>User</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($payment->user->name); ?></td>
                <td>$<?php echo e(number_format($payment->amount, 2)); ?></td>
                <td><?php echo e($payment->method); ?></td>
                <td><?php echo e($payment->created_at->format('Y-m-d')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($payments->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\admin\payments\index.blade.php ENDPATH**/ ?>