<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Membership Details</h2>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($membership->name); ?></h5>
            <p class="card-text"><strong>Duration:</strong> <?php echo e($membership->duration); ?> months</p>
            <p class="card-text"><strong>Price:</strong> $<?php echo e($membership->price); ?></p>

            <a href="<?php echo e(route('memberships.index')); ?>" class="btn btn-secondary">Back to List</a>
            <a href="<?php echo e(route('memberships.edit', $membership->id)); ?>" class="btn btn-warning">Edit</a>

            <form action="<?php echo e(route('memberships.destroy', $membership->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\memberships\show.blade.php ENDPATH**/ ?>