<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="my-4 text-center">Manage Appointments</h2>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Add New Appointment Button -->
    <div class="d-flex justify-content-end mb-3">
        <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-dark">+ Add Appointment</a>
    </div>

    <!-- Appointments Table -->
    <div class="card shadow">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Client</th>
                        <th>Trainer</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(optional($appointment->client)->name ?? 'Not Assigned'); ?></td>
                            <td><?php echo e(optional($appointment->trainer)->name ?? 'Not Assigned'); ?></td>
                            <td><?php echo e($appointment->date); ?></td>
                            <td><?php echo e($appointment->time); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($appointment->status == 'Confirmed' ? 'success' : 'warning'); ?>">
                                    <?php echo e($appointment->status ?? 'Pending'); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <form action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">No appointments found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\index.blade.php ENDPATH**/ ?>