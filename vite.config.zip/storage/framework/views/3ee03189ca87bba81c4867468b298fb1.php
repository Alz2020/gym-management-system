<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>📊 Track Your Progress</h2>
    <p>Welcome, <?php echo e(auth()->user()->name); ?>! Here is your fitness progress:</p>

    <?php if($progress->isEmpty()): ?>
        <p>No progress records found.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                    <th>Body Fat (%)</th>
                    <th>Workout Sessions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($entry->created_at->format('d M Y')); ?></td>
                        <td><?php echo e($entry->weight ?? 'N/A'); ?></td>
                        <td><?php echo e($entry->body_fat ?? 'N/A'); ?></td>
                        <td><?php echo e($entry->workout_sessions); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\progress\index.blade.php ENDPATH**/ ?>