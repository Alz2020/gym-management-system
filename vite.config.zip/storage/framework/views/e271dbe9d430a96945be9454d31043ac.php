<?php $__env->startSection('content'); ?>
<h1>Trainer Dashboard</h1>
<p>welcome, <?php echo e(Auth()->name); ?>!</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\user\trainer.blade.php ENDPATH**/ ?>