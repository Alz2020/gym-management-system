<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4">💳 Manage Payments</h2>
    <p>View and manage your payments below.</p>

    <!-- Payment Table -->
    <table class="table table-striped">
        <thead class="thead-dark">
            <tr>
                <th>#</th>
                <th>Payment ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($payment->payment_reference); ?></td>
                    <td>£<?php echo e(number_format($payment->amount, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($payment->status == 'Completed' ? 'success' : 'warning'); ?>">
                            <?php echo e(ucfirst($payment->status)); ?>

                        </span>
                    </td>
                    <td><?php echo e($payment->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <a href="<?php echo e(route('payments.show', $payment->id)); ?>" class="btn btn-info btn-sm">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No payment records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Payment Actions -->
    <a href="<?php echo e(route('payments.create')); ?>" class="btn btn-primary">💰 Make a Payment</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\payments\index.blade.php ENDPATH**/ ?>