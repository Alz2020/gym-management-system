<h2>Welcome to the Dashboard</h2>
<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit">Logout</button>
</form>
<?php /**PATH C:\wamp64\www\gym-management-system\resources\views\auth\dashboard.blade.php ENDPATH**/ ?>