<?php $__env->startSection('content'); ?>
    <h1>Member Dashboard</h1>
    <p>Welcome, <?php echo e(Auth::user()->name); ?>!</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\user\member.blade.php ENDPATH**/ ?>