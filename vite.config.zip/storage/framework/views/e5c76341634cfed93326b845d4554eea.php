<?php $__env->startSection('content'); ?>
    <h2>Membership Plans</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Duration</th>
            </tr>
        </thead>
        <tbody>
<?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($membership->id); ?></td>
        <td><?php echo e($membership->name); ?></td>
        <td><?php echo e($membership->description); ?></td>
        <td>£<?php echo e($membership->price); ?></td>
        <td><?php echo e($membership->duration); ?> months</td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($membership->links()); ?> 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\admin\memberships\index.blade.php ENDPATH**/ ?>