<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
    <h2>Your OTP Code</h2>
    <p>Your OTP code for login is: <strong><?php echo e($otp); ?></strong></p>
    <p>This code will expire soon. Do not share it with anyone.</p>
</body>
</html>
<?php /**PATH C:\wamp64\www\gym-management-system\resources\views\emails\otp.blade.php ENDPATH**/ ?>