<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mt-4">💰 Make a Payment</h2>

    <form action="<?php echo e(route('payments.store')); ?>" method="POST" class="mt-3">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="amount" class="form-label">Amount (£)</label>
            <input type="number" name="amount" class="form-control" step="0.01" min="1" required>
        </div>

        <div class="mb-3">
            <label for="payment_reference" class="form-label">Payment Reference</label>
            <input type="text" name="payment_reference" class="form-control" placeholder="e.g. PAY123456" required>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" class="form-select" required>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Submit Payment</button>
        <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\payments\create.blade.php ENDPATH**/ ?>