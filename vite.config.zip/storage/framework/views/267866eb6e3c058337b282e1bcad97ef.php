<?php $__env->startSection('content'); ?>
    <h1>Memberships</h1>
    <a href="<?php echo e(route('memberships.create')); ?>">Create Membership</a>
    <ul>
        <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($membership->name); ?> - $<?php echo e($membership->price); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gym-management-system\resources\views\memberships\index.blade.php ENDPATH**/ ?>